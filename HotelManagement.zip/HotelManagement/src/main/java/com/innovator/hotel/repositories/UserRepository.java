package com.innovator.hotel.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.innovator.hotel.models.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long>{

}
